package com.example.demo.lambda.dynamodb.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "ProductInfo")
public class ProductInfo {
    private String productID;
    private String msrp;
    private String cost;

    public ProductInfo() {
    }

    public ProductInfo(String cost, String msrp) {
        this.msrp = msrp;
        this.cost = cost;
    }

    @DynamoDBHashKey(attributeName = "ProductID")
    public String getProductID() {
        return productID;
    }

    @DynamoDBAttribute(attributeName = "Msrp")
    public String getMsrp() {
        return msrp;
    }

    @DynamoDBAttribute(attributeName = "Cost")
    public String getCost() {
        return cost;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public void setMsrp(String msrp) {
        this.msrp = msrp;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }
}
