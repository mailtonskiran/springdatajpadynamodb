package com.example.demo.lambda;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.amazonaws.services.lambda.runtime.Context;
import com.example.demo.lambda.dynamodb.model.ProductInfo;
import com.example.demo.lambda.dynamodb.repositories.ProductInfoRepository;

public class LambdaMethodHandler {

	static AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(
			LambdaDynamoJpaApplication.class.getPackage().getName());

	public LambdaMethodHandler() {
	        ctx.getAutowireCapableBeanFactory().autowireBean(this);
	    }

	@Autowired
	private ProductInfoRepository productInfoRepository;

	public ProductInfo handleRequest(String input, Context context) {
		context.getLogger().log("Input: " + input);
		return productInfoRepository.findById(input).get();
	}
}